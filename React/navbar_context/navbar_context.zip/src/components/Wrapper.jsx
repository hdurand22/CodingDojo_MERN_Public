import { Children, useContext, useState } from "react";
import NavContext from "./NavContext";

const Wrapper = props => {
    // const context = useContext(NavContext);
    // console.log('context: ' + context);

    // Create a state for the name to be displayed in the nav bar
    const [username, setUsername] = useState("Unregistered user");
    // console.log("username: " + username);

    return (
        <>
            <NavContext.Provider value = {{username, setUsername}}>
                {props.children}
            </NavContext.Provider>
        </>
    )

};

export default Wrapper;