import React, {useContext} from 'react';
import NavContext from './NavContext';

const Form = () => {
    const {username, setUsername} = useContext(NavContext);

    return (
        <form>
            <label htmlFor="username">Your Name: </label>
            <input type="text" onChange={event => setUsername(event.target.value)}/>
        </form>
    )

};

export default Form;