import { useContext } from "react";
import NavContext from "./NavContext";

const Navbar = () => {
    const context = useContext(NavContext);
    console.log('context: ' + context);
    return (
        <header>
            <h1>Hello {context.username}</h1>
        </header>
    )
};

export default Navbar;

