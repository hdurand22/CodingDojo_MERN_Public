import {useContext} from 'react';
import Form from './Form';
import NavContext from './NavContext';

const FormWrapper = () => {
    // const context = useContext(NavContext);

    return (
        <div>
            <Form/>
        </div>
    )
}

export default FormWrapper;