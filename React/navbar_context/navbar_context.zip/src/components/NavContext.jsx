import { createContext } from "react";

const NavContext = createContext();

export default NavContext;