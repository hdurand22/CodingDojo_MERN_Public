import './App.css';
import NavContext from './components/NavContext';
import Wrapper from './components/Wrapper';
import FormWrapper from './components/FormWrapper';
import Form from './components/Form';
import Navbar from './components/Navbar';
import {useState} from 'react';


function App() {
  return (
      <div className="App">
          <Wrapper>
            <Navbar/> 
            <FormWrapper/>
          </Wrapper>
      </div>
  );
}

export default App;
