import './App.css';
import Task from './components/Task';
import {useState} from 'react';
import Display from './components/Display';

function App() {
  // Declare a variable for holding all of the user's tasks
  const [list, setList] = useState([]);
  
  return (
    <div className="App">
      {/* <div>
        <Task taskState={taskState}/>
      </div>
      {
        tasks.map((list, i) => {
          return <Display list={list} setList={setList} />
        })
      }
      <div>
        <h2>{tasks[idx].content}</h2>
        <>
          <label htmlFor="isDone">
              <input type="checkbox" checked={isDone} onChange={(e) => setIsDone(e.target.checked)}/>
          </label>
        </>
      </div> */}
      <Display list={list} setList={setList}/>
      {
        list.map((task, idx) => {
          return <Task key={idx} task={task} idx={idx} list={list} setList={setList} />
        })
      }
    </div>
  );
}

export default App;
