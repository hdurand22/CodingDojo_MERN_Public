import React, {useState} from 'react';

const Task = props => {
    const {task, list, setList, idx} = props; // Destructure the props from App.js

    const [isDone, setIsDone] = useState(false); // State for tracking task completion

    const handleClick = (e) => {
        setList(() => {
            return list.filter(task => list.indexOf(task) !== idx);
        });
    };

    const handleChange = () => {
        list[idx].isDone = !list[idx].isDone; // Change 'false' to 'true'
        if (list[idx].textDecorationLine == 'none') {
            list[idx].textDecorationLine = 'line-through';
        }
        else {
            list[idx].textDecorationLine = 'none';
        }
        setList([...list]);
    };

    return (
        <div>
            <h3 style={{textDecorationLine: task.textDecorationLine}}>{task.content}</h3>
            <label htmlFor="isDone">Completed?</label>
            <input type="checkbox" checked={task.isDone} onChange={handleChange}/>
            <button onClick={handleClick}>Delete Task</button>
        </div>
    )
}

export default Task;