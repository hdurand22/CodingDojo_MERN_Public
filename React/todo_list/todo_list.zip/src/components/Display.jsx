import React, {useState} from 'react';
import Task from './Task';

const Display = props => {
    const {list, setList} = props;
    let task = {
        content: '',
        isDone: false,
        textDecorationLine: 'none'
    };

    const handleChange = (e) => {
        task.content = e.target.value;
    };

    const handleSubmit = (e) => {
        setList([...list, task]);
        e.target.value="";
    };
    
    return (
        <div>
            <label htmlFor="task">Task description:</label>
            <input type="text" name="task" onChange={handleChange}/>
            <button onClick={handleSubmit}>Add Task</button>
        </div>
    )
};

export default Display;