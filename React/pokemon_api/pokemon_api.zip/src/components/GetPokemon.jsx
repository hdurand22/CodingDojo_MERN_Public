import React, { useEffect, useState } from 'react';

const GetPokemon = () => {

    const[fetchState, setFetchState] = useState();

    const handleClick = () => {
        fetch("https://pokeapi.co/api/v2/pokemon/?limit=807")
            .then(response => response.json())
            .then(response => setFetchState(response.results))
            .catch(err => console.log(err))
    };

    return (
        <div>
            <button onClick={handleClick}>Fetch Pokemon</button>
            {
                (fetchState) ? (fetchState.map((pokemon, i) => { return <div key={i}>{pokemon.name}</div> })) : <h1>Gotta catch 'em all!</h1>
            }
        </div>
    );
};

export default GetPokemon;