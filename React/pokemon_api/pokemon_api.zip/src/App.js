import GetPokemon from './components/GetPokemon';
import './App.css';

function App() {
  return (
    <div className="App">
      <GetPokemon />
    </div>
  );
}

export default App;
