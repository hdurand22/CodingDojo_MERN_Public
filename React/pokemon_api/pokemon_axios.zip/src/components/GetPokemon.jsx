import React, { useState } from 'react';
import axios from 'axios';

const GetPokemon = () => {

    const[fetchState, setFetchState] = useState();
    

    const handleClick = () => {
        axios.get("https://pokeapi.co/api/v2/pokemon/?limit=807")
            .then(response => { setFetchState(response.data)} )
            .catch(err => console.log(err))
    }

    return (
        <div>
            <button onClick={handleClick}>Fetch Pokemon</button>
            {
                (fetchState) ? (fetchState.results.map((pokemon, i) => { return <div key={i}>{pokemon.name}</div> })) : <h1>Gotta catch 'em all!</h1>
            }
        </div>
    );
};

export default GetPokemon;