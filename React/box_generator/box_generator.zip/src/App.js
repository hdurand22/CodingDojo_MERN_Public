import {useState} from 'react';
import { Provider } from 'styletron-react';
import { Client as Styletron } from 'styletron-engine-atomic';
import Form from './components/Form';
import Box from './components/Box';
import StyledBox from './components/StyledBox';
import './App.css';

const engine = new Styletron();

function App() {
  const [boxes, setBoxes] = useState([]);

  return (
    <Provider value= {engine}>
      {
        <StyledBox $border='0px' $bgColor='white' $width='80vw' $height='10vw' $flexDir='row' $justifyContent='center'>
          <Form setBoxes={setBoxes} boxes={boxes}>
            <StyledBox $border='0px' $bgColor='white'>
            {
              boxes.map((box, i) => <Box key={i} box={box}/>)
            }
            </StyledBox>
          </Form>
        </StyledBox>
      }
    </Provider>
  );
}

export default App;
