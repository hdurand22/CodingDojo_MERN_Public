import React, { useState } from 'react';


const Form = (props) => {
    const {boxes, setBoxes} = props;

    const [formState, setFormState] = useState({
        color: '',
        size: ''
    });

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormState ({
            ...formState,
            [name]: value
        });
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        // Store the box color input
        setBoxes([...boxes, formState]);
        // Reset the form
        setFormState({
            color: '',
            size: ''
        });
    }

    return (
        <form onSubmit={handleSubmit}>
            <h3>Color</h3>
            <p>
                <label htmlFor="color"></label>
                <input type="text" name="color" value={formState.color} onChange={handleChange}></input>
            </p>
            <h3>Box Size</h3>
            <p>
                <label htmlFor="size"></label>
                <input type="text" name="size" value={formState.size} onChange={handleChange}></input>
            </p>
            <p>
                <button type="submit">Add</button>
            </p>
            {props.children}
        </form>
    )




}

export default Form;