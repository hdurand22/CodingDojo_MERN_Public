import React from 'react';
import { styled } from 'styletron-react';

const StyledBox = styled('div', props => ({
    border: ( props.$border || '2px solid black'),
    background: props.$bgColor,
    margin: (props.$margin || '10px'),
    padding: (props.$padding || '20px'),
    width: props.$width,
    height: (props.$height || ""),

    display: (props.$display || 'flex'),
    flex: props.$flex,
    flexDirection: props.$flexDir,
    alignItems: (props.$alignItems || ''),
    justifyContent: props.$justifyContent,

    ['@media and (min-width: ' + (props.$minWidth || '500px') + ')']: {
        display: 'block'
    }
}));

export default StyledBox;