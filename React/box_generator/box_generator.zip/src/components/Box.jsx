import { getDefaultNormalizer } from '@testing-library/react';
import React, { useState } from 'react';
import StyledBox from './StyledBox';

const Box = props => {
    // Destructure the box color from the props passed down by the app/form submission
    const {box} = props;
    const size = box.size.concat('px');

    return (
        <StyledBox $bgColor={box.color} $width={size} $height={size} />
    );

}

export default Box;