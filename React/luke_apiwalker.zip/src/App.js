import {Router} from '@reach/router';
import Form from './components/Form';
import Results from './components/Results';
import { useState } from 'react';
import './App.css';

function App() {
  
  const [request, setRequest] = useState({
    'filter': "people",
    'searchID': 1
  });


  return (
    <div className="App">
      <Form request={request} setRequest={setRequest} path="/"/>
      <Router>
        <Results request={request} setRequest={setRequest} path="/results/:filter/:searchID"/>
      </Router>
    </div>
  );
}

export default App;
