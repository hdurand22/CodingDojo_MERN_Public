import { navigate } from '@reach/router';
import axios from 'axios';
import React, {useEffect, useState} from 'react';

const Results = props => {
    const {request} = props;
    
    const [responseData, setResponseData] = useState(null);

    // const [submitState, setSubmitState] = useState(false)

    const [error, setError] = useState(false);

    console.log(request);
    

    useEffect(() => {
        axios.get(`https://swapi.dev/api/${request.filter}/${request.searchID}`)
            .then(response => {
                console.log("in get request");
                setResponseData(response.data)
                console.log('responseData:'+ responseData);
                // setSubmitState(true)
                setError(false)
            })         
            .catch(() => {
                setError(true)
                // console.log('error')
            })
    }, [props]);
    
    if (request.filter === 'people' && !error) {
        return (
            <div>
                {
                (responseData) ?
                <div>
                    <p>Name: {responseData.name} </p>
                    <p>Height (cm): {responseData.height} </p>
                    <p>Mass (kg): {responseData.mass} </p>
                    <p>Birth Year: {responseData.birth_year} </p>
                </div>
                    : null
                }
            </div>
        )
    }
    if (request.filter === 'planets' && !error) {
        return (
            <div>
                {
                (responseData) ?
                <div>
                    <p>Name: {responseData.name} </p>
                    <p>Climate: {responseData.climate} </p>
                    <p>Terrain: {responseData.terrain} </p>
                    <p>Population: {responseData.population} </p>
                </div>
                    : null
                }
            </div>
        )
    }
    if (error) {
        return (
            <div>
                <h2>These aren't the droids you're looking for...</h2>
                <img src="https://media1.tenor.com/images/260d16f8a5615370fba858a4aaec34a4/tenor.gif" alt="Obi-Wan" />
            </div>
        )
    }
    // else if (!responseData) {
    //     navigate('/')
    // }

};

export default Results;