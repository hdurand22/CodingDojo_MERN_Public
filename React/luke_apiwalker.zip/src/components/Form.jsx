import React, { useState } from 'react';
// import axios from 'axios';
import { navigate } from '@reach/router';

const Form = props => {
    
    const {request, setRequest} = props;

    // Capture default form inputs
    const [form, setForm] = useState({
        ...request,
    }); 
    
    const handleChange = event => {
        event.preventDefault();
        // console.log("event: "+event.target.name);
        // console.log('form: '+form);
        setForm({
            ...form,
            [event.target.name]: event.target.value
        });
        // console.log(form);
    }

    const handleSubmit = event => {
        event.preventDefault();
        const {filter, searchID} = form;
        // console.log('filter: '+filter);
        // console.log('searchID: '+searchID);
        setRequest(
            {
                "filter": filter,
                "searchID": searchID
            }
        );
        navigate(`/results/${filter}/${searchID}`);
        // console.log('request: '+request);
    }
    
    return (
        <>
            <form onSubmit={handleSubmit} >
                <label htmlFor="search">Search for: </label>
                <select name="filter" onChange={handleChange}>
                    <option value="people">People</option>
                    <option value="planets">Planets</option>
                </select>
                <label htmlFor="searchID">ID: </label>
                <input type="number" name="searchID" min="1" onChange={handleChange}/>
                <button>Search</button>
            </form>
        </>
    )
};

export default Form;
