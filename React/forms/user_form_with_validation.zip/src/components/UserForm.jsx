import React, { useState } from "react";

const UserForm = props => {
    const [formState, setFormState] = useState({
        firstName : '',
        lastName : '',
        email : '',
        password : '',
        confirmPassword : '',
        isSubmitted: false
    })

    const [validState, setValidState] = useState({
        firstName: false,
        lastName: false,
        email: false,
        password: false,
        confirmPassword: false
    })

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormState({
            ...formState,
            [name] : value
        });
    }

    // Validate user input in the form and create a new user upon valid submission
    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent request
        const newUser = {...formState};

        // Validate first name entry
        if (formState.firstName.length < 2) {
            var firstName = true;
        }
        // Validate last name entry
        if (formState.lastName.length < 2) {
            var lastName = true;
        }
        // Validate email address entry
        if (! (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(formState.email)) {
            var email = true;
        }
        // Check password validations
        if (formState.password.length < 8) {
            var password = true;
        }
        // Check confirm password
        if (formState.password !== formState.confirmPassword) {
            var confirmPassword = true;
        }

        setValidState({
            ...validState,
            firstName,
            lastName,
            email,
            password,
            confirmPassword
        });

        // for (let value in validState) {
        //     console.log(typeof value);
        // }

    };

    return (
        <>
            <form onSubmit={handleSubmit}>
                {/* {
                    formState.isSubmitted ?
                    <h3>Thank you for submitting the form!</h3> :
                    <h3>Welcome! Please fill out and submit the form.</h3>
                } */}
                <div>
                    <label htmlFor="firstName">First Name:</label>
                    <input type="text" name="firstName" onChange={ handleChange } value= {formState.firstName} />
                    { (validState.firstName) ? <h3>First name must be at least 2 characters.</h3> : null }
                </div>
                <div>
                    <label htmlFor="lastName">Last Name:</label>
                    <input type="text" name="lastName" onChange={ handleChange } value={formState.lastName} />
                    { (validState.lastName) ? <h3>Last name must be at least 2 characters.</h3> : null }
                </div>
                <div>
                    <label htmlFor="email">Email:</label>
                    <input type="text" name="email" onChange={ handleChange } value={formState.email} />
                    { (validState.email) ? <h3>Please use a valid email format</h3> : null }
                </div>
                <div>
                    <label htmlFor="password">Password:</label>
                    <input type="password" name="password" onChange={ handleChange } value={formState.password} />
                    { (validState.password) ? <h3>Password must be at least 8 characters</h3> : null }
                </div>
                <div>
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input type="password" name="confirmPassword" onChange= { handleChange } value={formState.confirmPassword} />
                    { (validState.confirmPassword) ? <h3>Passwords must match</h3> : null }
                </div>
                <input type="submit" value="Create User" />
            </form>
        </>
    );

};

export default UserForm;