import React from 'react';
import { Provider, DebugEngine } from 'styletron-react';
import { Client as Styletron } from 'styletron-engine-atomic';
import Header from './components/Header';
import Main from './components/Main';
import Navigation from './components/Navigation';
import StyledBox from './components/StyledBox';
import SubContent from './components/SubContent';
import Advertisement from './components/Advertisement';

const debug = process.env.NODE_ENV === "production" ? void 0 : new DebugEngine();
const engine = new Styletron();

function App() {
  return (
    <Provider value={engine} debug={debug} debugAfterHydration>
        <StyledBox $bgColor="gray" $flexDir="column" $width="90vw" $height="100%">
          <Header />
          <StyledBox $margin="10px 0px" $border="0px" $padding="0px" >
            <Navigation />
            <Main >
              <StyledBox $padding="0px" $margin="0px" $border="none" $justifyContent="space-between">
                <SubContent /> 
                <SubContent /> 
                <SubContent /> 
              </StyledBox>
              <Advertisement /> 
            </Main>
          </StyledBox> 
        </StyledBox>
    </Provider>
  )
}

export default App;