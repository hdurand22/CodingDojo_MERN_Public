import React from 'react';
import StyledBox from './StyledBox';

const Navigation = props => {
    return (
        <>
            <StyledBox $margin="10px 10px 10px 0px" $bgColor="blue" $width="15vw" $height="25vw" />
        </>
    );
}

export default Navigation;