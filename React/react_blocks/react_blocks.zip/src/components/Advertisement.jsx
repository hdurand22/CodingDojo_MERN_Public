import React from 'react';
import StyledBox from './StyledBox';

const Advertisement = props => {
    return (
        <>
            <StyledBox $bgColor="purple" $width="1" $height="45px"/>
        </>
    );
}

export default Advertisement;