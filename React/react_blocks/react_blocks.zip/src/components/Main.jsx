import React from 'react';
import StyledBox from './StyledBox';

const Main = props => {
    return (
        <>
            <StyledBox $margin="10px 0px 10px 10px" $bgColor="red" $width="85vw" $height="100%" $flexDir="column">
                {props.children}
            </StyledBox>
        </>
    ); 
    
}

export default Main;