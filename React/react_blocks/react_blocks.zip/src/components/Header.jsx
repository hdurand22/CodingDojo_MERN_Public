import React from 'react';
import StyledBox from './StyledBox';

const Header = props => {
    return (
        <>
            <StyledBox $bgColor="green" $height="15px" $margin="0px"/>
        </>
    );
}

export default Header;