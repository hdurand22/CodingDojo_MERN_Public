import React from 'react';
import StyledBox from './StyledBox';

const SubContent = props => {
    return (
        <>
            <StyledBox $bgColor="yellow"  $width="15vw" $height="20vw"/>
        </>
    );
}

export default SubContent;