// const user = require('User');
// const company = require('Company');


const faker = require('faker');
const express = require("express");
const app = express();
const port = 8000;


class User {
    constructor() {
        this._id = faker.datatype.uuid();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
    }
}

class Company {
  constructor() {
      this._id = faker.datatype.uuid();
      this.name = faker.company.companyName();
      this.address = {
          'street': faker.address.streetAddress(),
          'city': faker.address.city(),
          'state': faker.address.state(),
          'zipcode': faker.address.zipCode(),
          'country': faker.address.country
      }
  }
}

// var user = new User();

// var company = new Company();

// req is short for request
// res is short for response
app.get("/api", (req, res) => {
  res.send("Our express api server is now sending this over to the browser");
});

app.get("/api/user/new", (req, res) => {
  return res.json(new User());
});

app.get("/api/company/new", (req, res) => {
  return res.json(new Company());
});

app.get("/api/user/company", (req, res) => {
  let results = res.json({
    'user': new User(),
    'company': new Company()
  });
  return results;
});

const server = app.listen(8000, () =>
  console.log(`Server is locked and loaded on port ${server.address().port}!`)
);


