import React from 'react';
import NewComponent from '../components/NewComponent';

const NewAuthor = () => {
    return (
        <div>
            <NewComponent/>
        </div>
    )
}

export default NewAuthor;