const { response } = require('express');
const { Product } = require('../models/product.model');

module.exports.index = (req, res) => {
    res.json({
        message: "Test"
    });
};

module.exports.getAllProducts = (req, res) => {
    Product.find({})
        .then(allProducts => res.json({allProducts}))
        .catch(err => res.json({err}))
};

module.exports.getOneProduct = (req, res) => {
    Product.findOne({_id: req.params.id})
        .then(product => res.json(product))
        .catch(err => res.json(err))
};

module.exports.createProduct = (req, res) => {
    // console.log('in the create controller method');
    const { title, price, description } = req.body;
    Product.create({
        title,
        price,
        description
    })
        .then(product => res.json(product))
        .catch(err => res.status(400).json(err));
};

module.exports.updateProduct = (req, res) => {
    // console.log('in the update product route')
    Product.findOneAndUpdate({_id: req.params.id}, req.body, {new: true, runValidators: true})
        .then(updatedProduct => res.json(updatedProduct))
        .catch(err => res.status(400).json(err));
};

module.exports.deleteProduct = (req, res) => {
    Product.deleteOne({_id: req.params.id})
        .then(confirmation => res.json(confirmation))
        .catch(err => res.json(err));
};