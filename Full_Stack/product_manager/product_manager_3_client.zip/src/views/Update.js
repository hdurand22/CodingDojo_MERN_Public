import React, { useEffect, useState } from 'react';
import { navigate, Link } from '@reach/router';
import axios from 'axios';

const Update = props => {
    const {id} = props;

    const [formState, setFormState] = useState({
        title: "",
        price: 0,
        description: ""
    });

    const [validState, setValidState] = useState({});

    useEffect(() => {
        axios.get(`http://localhost:8000/api/products/${id}`)
            .then(res => setFormState(res.data))
            .catch(err => console.log(err))
    }, []);

    const handleChange = event => {
        setFormState({
            ...formState,
            [event.target.name] : event.target.value
        })
    };

    const handleSubmit = event => {
        event.preventDefault();

        axios.put(`http://localhost:8000/api/products/${id}`, formState)
            .then(res => navigate(`/products/${id}`))
            .catch(err => {
                // console.log(err);
                const {errors} = err.res.data;
                let errorObj = {};
                for (let [key, value] of Object.entries(errors)) {
                    errorObj[key] = value.message;
                }
                setValidState(errorObj);
            });
    };

    const handleDelete = () => {
        axios.delete(`http://localhost:8000/api/products/${id}`)
            .then(res => navigate("/"))
            .catch(err => console.log(err));
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <p>
                    <label htmlFor="title">Title </label>
                    <input type="text" name="title" onChange={handleChange} value={formState.title}/>
                    {(validState.title) ? <p>{validState.title}</p> : null}
                </p>
                <p>
                    <label htmlFor="price">Price </label>
                    <input type="number" name="price" onChange={handleChange} value={formState.price}/>
                    {(validState.price) ? <p>{validState.price}</p> : null}
                </p>
                <p>
                    <label htmlFor="description">Description </label>
                    <input type="text" name="description" onChange={handleChange} value={formState.description}/>
                    {(validState.description) ? <p>{validState.description}</p> : null}
                </p>
                <button type="submit">Update</button>
            </form>
            <button onClick={handleDelete}>Delete Product</button>
            <br/>
            <Link to={"/"}>Home</Link>
        </div>
    )

}

export default Update;