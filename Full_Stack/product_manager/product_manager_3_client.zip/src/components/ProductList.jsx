import React, {useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from '@reach/router';

const ProductList = props => {
    
    const { submitState, setSubmitState } = props;

    // Create an empty list of all of our products
    const [ products, setProducts ] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/products')
            .then(res => setProducts(res.data.allProducts))
            .catch(err => console.log(err))
    }, [submitState]);

    const handleDelete = (product_id) => {
        // console.log("in delete handler in product list component");
        axios.delete(`http://localhost:8000/api/products/${product_id}`)
            .then(res => setSubmitState(!submitState))
            .catch(err => console.log(err));
    };

    return (
        <ul>
        {products.map((product, i) => {
            return (
                <p>
                    <li key={i}><Link to={`/products/${product._id}`}>{product.title}</Link></li>
                    <button onClick={() => handleDelete(product._id)}>Delete Product</button>
                </p>
                    )
                })}
        </ul>
    )
}

export default ProductList;